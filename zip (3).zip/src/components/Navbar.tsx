import { Link, useLocation } from "react-router";
import { Building2, Home, Search, ShieldCheck, User } from "lucide-react";
import { cn } from "../lib/utils";

export default function Navbar() {
  const location = useLocation();
  const navItems = [
    { name: "Home", path: "/", icon: Home },
    { name: "Find Hostels", path: "/hostels", icon: Search },
    { name: "Safety & Tools", path: "/tools", icon: ShieldCheck },
    { name: "Admin", path: "/admin", icon: User },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2">
              <Building2 className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-primary to-orange-500 bg-clip-text text-transparent">
                StayNest
              </span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
                  location.pathname === item.path
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.name}
              </Link>
            ))}
          </div>

          <div className="flex items-center md:hidden">
            {/* Mobile menu could go here */}
            <Building2 className="h-6 w-6 text-primary" />
          </div>
        </div>
      </div>
    </nav>
  );
}
