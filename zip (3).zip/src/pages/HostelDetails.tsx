import { useParams, Link } from "react-router";
import { hostels, reviews } from "../data/mockData";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { MapPin, ShieldCheck, CheckCircle2, Star, ChevronLeft, BedDouble, CalendarDays, Clock, Camera } from "lucide-react";

export default function HostelDetails() {
  const { id } = useParams();
  const hostel = hostels.find(h => h.id === id);
  const hostelReviews = reviews.filter(r => r.hostelId === id);

  if (!hostel) {
    return <div className="container py-20 text-center text-xl font-medium">Hostel not found. <Link to="/hostels" className="text-primary hover:underline">Go back</Link></div>;
  }

  return (
    <div className="flex-1 bg-muted/10 pb-20">
      {/* Immersive Header Image (like Recipe 7 setup but clean) */}
      <div className="relative w-full h-[40vh] min-h-[300px] overflow-hidden bg-black">
        <img src={hostel.imageUrl} alt={hostel.name} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        
        <div className="absolute inset-x-0 bottom-0 top-0 container px-4 mx-auto flex flex-col justify-end pb-8">
          <Link to="/hostels" className="inline-flex items-center text-sm font-medium hover:text-primary transition-colors text-white/80 hover:text-white mb-6 absolute top-8">
            <ChevronLeft className="h-4 w-4 mr-1" /> Back to search
          </Link>
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 relative z-10">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <Badge className="bg-primary/90 hover:bg-primary text-white pointer-events-none uppercase tracking-wider text-xs px-3">{hostel.type}</Badge>
                {hostel.safetyScore >= 90 && (
                  <Badge className="bg-blue-500/90 hover:bg-blue-500 text-white pointer-events-none">
                    <ShieldCheck className="w-3 h-3 mr-1" /> Safe Pick
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white font-sans">{hostel.name}</h1>
              <p className="text-white/80 flex items-center mt-3 text-lg">
                <MapPin className="h-4 w-4 mr-1" /> {hostel.area}
              </p>
            </div>
            
            <div className="bg-background rounded-xl p-5 shadow-xl border w-full md:w-auto md:min-w-[280px] shrink-0 transform md:translate-y-12 shrink-0">
              <p className="text-sm font-medium text-muted-foreground mb-1">Starting Rent</p>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-4xl font-black font-mono tracking-tighter">₹{hostel.rent}</span>
                <span className="text-muted-foreground">/mo</span>
              </div>
              <Button className="w-full rounded-full h-12 text-md mb-3" size="lg">Book a Visit</Button>
              <Button variant="outline" className="w-full rounded-full h-12">Reserve Room</Button>
              <p className="text-xs text-center text-muted-foreground mt-3 flex items-center justify-center">
                <CalendarDays className="h-3 w-3 mr-1" /> <span>{hostel.availableRooms} rooms left</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-8 md:mt-20">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-10">
            
            <section>
              <h2 className="text-2xl font-bold mb-4 font-sans tracking-tight">About this {hostel.type} stay</h2>
              <p className="text-muted-foreground text-lg leading-relaxed">{hostel.description}</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-6 font-sans tracking-tight">Amenities provided</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {hostel.amenities.map(a => (
                  <div key={a} className="flex items-center gap-3 bg-background border p-4 rounded-xl shadow-sm">
                    <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0" />
                    <span className="font-medium text-sm">{a}</span>
                  </div>
                ))}
              </div>
            </section>
            
            <section className="bg-orange-50 dark:bg-orange-950/20 rounded-2xl p-6 md:p-8 border border-orange-100 dark:border-orange-900/30">
               <h2 className="text-2xl font-bold mb-6 font-sans tracking-tight flex items-center gap-2">
                 <ShieldCheck className="h-6 w-6 text-orange-500" /> Safety Score Meter
               </h2>
               <div className="flex flex-col md:flex-row items-center gap-8">
                  <div className="w-32 h-32 rounded-full border-8 border-orange-200 dark:border-orange-900 relative flex items-center justify-center shrink-0">
                    <div 
                      className="absolute inset-0 rounded-full border-8 border-orange-500"
                      style={{ clipPath: `polygon(0 0, 100% 0, 100% ${hostel.safetyScore}%, 0 ${hostel.safetyScore}%)` }}
                    />
                    <div className="text-3xl font-black font-mono text-foreground text-center relative z-10">{hostel.safetyScore}</div>
                  </div>
                  <div className="flex-1 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-0.5 text-green-500" />
                        <div><p className="font-medium text-sm">CCTV Coverage</p><p className="text-xs text-muted-foreground">Common areas & gates</p></div>
                      </div>
                      <div className="flex items-start gap-2">
                         <CheckCircle2 className="h-4 w-4 mt-0.5 text-green-500" />
                        <div><p className="font-medium text-sm">Warden</p><p className="text-xs text-muted-foreground">On-site 24/7</p></div>
                      </div>
                      <div className="flex items-start gap-2">
                         <Clock className="h-4 w-4 mt-0.5 text-blue-500" />
                        <div><p className="font-medium text-sm">Curfew Time</p><p className="text-xs text-muted-foreground">{hostel.curfew}</p></div>
                      </div>
                    </div>
                  </div>
               </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-6 font-sans tracking-tight flex items-center justify-between">
                Reviews
                <div className="flex items-center text-lg bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-400 px-3 py-1 rounded-md">
                  <Star className="h-5 w-5 mr-1 fill-current" /> {hostel.rating}
                </div>
              </h2>
              {hostelReviews.length > 0 ? (
                <div className="space-y-4">
                  {hostelReviews.map((review) => (
                    <div key={review.id} className="bg-background border p-5 rounded-xl shadow-sm">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-bold">{review.author}</p>
                          <p className="text-xs text-muted-foreground">{review.date}</p>
                        </div>
                        <div className="flex items-center text-orange-500 text-sm font-bold">
                           <Star className="h-3 w-3 fill-current mr-0.5" /> {review.rating}
                        </div>
                      </div>
                      <p className="text-muted-foreground text-sm">{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground italic bg-background border p-5 rounded-xl">No reviews yet for this hostel.</p>
              )}
            </section>
          </div>
          
          <div className="hidden md:block">
            {/* Spacer for sticky mobile sidebar effect, or any extra desktop sidebar widgets */}
            <div className="sticky top-24 bg-background border rounded-xl p-6 shadow-sm">
               <h3 className="font-bold mb-4 flex items-center"><Camera className="w-4 h-4 mr-2"/> Virtual Tour</h3>
               <div className="aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center relative group cursor-pointer border">
                 <img src={hostel.imageUrl} alt="tour" className="w-full h-full object-cover blur-[2px] opacity-70 group-hover:blur-sm transition-all" referrerPolicy="no-referrer" />
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="w-12 h-12 bg-white/90 rounded-full shadow-lg flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                      ▶
                    </div>
                    <span className="font-bold text-white mt-2 drop-shadow-md">360° Tour</span>
                 </div>
               </div>
               
               <hr className="my-6" />
               <h3 className="font-bold mb-4 flex items-center"><BedDouble className="w-4 h-4 mr-2"/> Room Types</h3>
               <ul className="space-y-3 text-sm text-muted-foreground">
                 <li className="flex justify-between items-center bg-muted/30 p-2 border border-transparent hover:border-border rounded"><span className="font-medium text-foreground">Single Room</span> <span>Waitlist</span></li>
                 <li className="flex justify-between items-center bg-muted/30 p-2 border border-transparent hover:border-border rounded"><span className="font-medium text-foreground">Double Sharing</span> <span>₹{hostel.rent}/mo</span></li>
                 <li className="flex justify-between items-center bg-muted/30 p-2 border border-transparent hover:border-border rounded"><span className="font-medium text-foreground">Triple Sharing</span> <span>₹{hostel.rent - 500}/mo</span></li>
               </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
