import { useState } from "react";
import { Link } from "react-router";
import { Search, MapPin, ShieldCheck, Filter, Wifi, Wind, Coffee, WashingMachine } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { hostels, colleges } from "../data/mockData";
import { motion, AnimatePresence } from "motion/react";

export default function Hostels() {
  const [searchTerm, setSearchTerm] = useState("");
  const [genderFilter, setGenderFilter] = useState("All");
  const [collegeFilter, setCollegeFilter] = useState("All");
  const [maxRent, setMaxRent] = useState(15000);

  const filteredHostels = hostels.filter(h => {
    const matchesSearch = h.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          h.area.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGender = genderFilter === "All" || h.type === genderFilter;
    const matchesRent = h.rent <= maxRent;
    // Simple area match for college filter since we fake distance
    let matchesCollege = true;
    if (collegeFilter !== "All") {
      const col = colleges.find(c => c.id === collegeFilter);
      if (col && h.area !== col.area) matchesCollege = false;
    }
    return matchesSearch && matchesGender && matchesCollege && matchesRent;
  });

  return (
    <div className="flex-1 container mx-auto px-4 py-8 flex flex-col md:flex-row gap-8">
      {/* Sidebar Filters */}
      <aside className="w-full md:w-64 shrink-0 space-y-6">
        <div className="sticky top-24">
          <h2 className="text-xl font-bold flex items-center gap-2 mb-6">
            <Filter className="w-5 h-5" /> Filters
          </h2>
          
          <div className="space-y-6 bg-muted/30 p-6 rounded-xl border">
            <div className="space-y-3">
              <label className="text-sm font-semibold">Near College</label>
              <Select value={collegeFilter} onValueChange={setCollegeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select College" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Colleges</SelectItem>
                  {colleges.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-semibold">Gender</label>
              <div className="flex flex-col gap-2">
                {['All', 'Boys', 'Girls', 'Unisex'].map(g => (
                  <label key={g} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input 
                      type="radio" 
                      name="gender" 
                      value={g} 
                      checked={genderFilter === g}
                      onChange={(e) => setGenderFilter(e.target.value)}
                      className="accent-primary"
                    />
                    {g}
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-semibold flex justify-between">
                <span>Max Rent (₹)</span>
                <span className="text-primary font-bold">₹{maxRent}</span>
              </label>
              <input 
                 type="range" 
                 min="3000" 
                 max="15000" 
                 step="500" 
                 className="w-full accent-primary" 
                 value={maxRent}
                 onChange={(e) => setMaxRent(Number(e.target.value))}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>₹3K</span>
                <span>₹15K</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <label className="text-sm font-semibold">Amenities</label>
              <div className="grid grid-cols-2 gap-2">
                {['WiFi', 'AC', 'Mess', 'Laundry'].map(a => (
                  <label key={a} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" className="accent-primary rounded" />
                    {a}
                  </label>
                ))}
              </div>
            </div>
            
            <Button variant="outline" className="w-full mt-4" onClick={() => {
              setGenderFilter("All");
              setCollegeFilter("All");
              setSearchTerm("");
              setMaxRent(15000);
            }}>Clear Filters</Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Hostels in Pune</h1>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search area or hostel name..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2 text-sm">
          <Badge variant="secondary" className="px-3 py-1 text-xs">Sorted by: Recommendation</Badge>
          <span className="text-muted-foreground ml-auto">{filteredHostels.length} results</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AnimatePresence>
            {filteredHostels.map((hostel) => (
              <motion.div 
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                key={hostel.id}
              >
                <Link to={`/hostels/${hostel.id}`}>
                  <Card className="overflow-hidden hover:shadow-lg transition-all group h-full flex flex-col border-muted-foreground/20">
                    <div className="w-full h-48 overflow-hidden relative">
                      <img src={hostel.imageUrl} alt={hostel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                      <div className="absolute top-3 left-3 bg-white/95 dark:bg-black/90 px-2.5 py-1 rounded-sm text-xs font-bold uppercase tracking-wider">
                        {hostel.type}
                      </div>
                      <div className="absolute top-3 right-3 bg-green-500 text-white px-2 py-1 rounded text-xs font-bold flex items-center shadow-sm">
                        ⭐ {hostel.rating}
                      </div>
                      {hostel.safetyScore > 90 && (
                        <div className="absolute bottom-3 left-3 bg-blue-500/90 backdrop-blur-sm text-white px-2 py-1 rounded text-xs font-bold flex items-center">
                          <ShieldCheck className="h-3 w-3 mr-1" /> Top Safety
                        </div>
                      )}
                    </div>
                    
                    <CardContent className="p-5 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg group-hover:text-primary transition-colors line-clamp-1">{hostel.name}</h3>
                      </div>
                      
                      <p className="text-sm text-muted-foreground flex items-center mb-4">
                        <MapPin className="h-3 w-3 mr-1 shrink-0" /> <span className="line-clamp-1">{hostel.area} • {hostel.distance} km from college</span>
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mb-6">
                        {hostel.amenities.slice(0,3).map(a => (
                          <Badge key={a} variant="outline" className="bg-muted/50 text-xs font-normal">
                            {a}
                          </Badge>
                        ))}
                        {hostel.amenities.length > 3 && (
                          <Badge variant="outline" className="bg-muted/50 text-xs font-normal">+{hostel.amenities.length - 3}</Badge>
                        )}
                      </div>

                      <div className="mt-auto pt-4 border-t flex items-center justify-between">
                        <div>
                          <p className="text-xs text-muted-foreground">Starts from</p>
                          <p className="font-bold font-mono text-lg">₹{hostel.rent}<span className="text-sm font-sans font-normal text-muted-foreground">/mo</span></p>
                        </div>
                        <Button variant="secondary" size="sm" className="group-hover:bg-primary group-hover:text-primary-foreground transition-colors font-medium">
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
          {filteredHostels.length === 0 && (
            <div className="col-span-full py-20 text-center text-muted-foreground bg-muted/20 rounded-xl border border-dashed">
              <Search className="h-10 w-10 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No hostels found matching your criteria.</p>
              <Button variant="link" onClick={() => {
                setGenderFilter("All");
                setCollegeFilter("All");
                setSearchTerm("");
                setMaxRent(15000);
              }}>Clear all filters</Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
