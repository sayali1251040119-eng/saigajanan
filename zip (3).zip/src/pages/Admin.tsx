import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { hostels, reviews } from "../data/mockData";
import { Plus, Check, X, IndianRupee, MapPin, Building2, ShieldAlert } from "lucide-react";

export default function Admin() {
  const [activeTab, setActiveTab] = useState("listings");

  return (
    <div className="flex-1 bg-muted/10 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage listings, verify hostels, and view stats.</p>
          </div>
          <Button className="bg-foreground text-background hover:bg-foreground/80"><Plus className="w-4 h-4 mr-2"/> Add New Hostel</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Listings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{hostels.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Verifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-500">3</div>
            </CardContent>
          </Card>
          <Card>
             <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{reviews.length}</div>
            </CardContent>
          </Card>
           <Card>
             <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg. Rent in Pune</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold flex items-center">
                <IndianRupee className="w-6 h-6 mr-1" />
                {Math.round(hostels.reduce((acc, curr) => acc + curr.rent, 0) / hostels.length)}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="bg-background rounded-xl border shadow-sm">
          <div className="border-b px-4 flex gap-6">
            <button 
              className={`py-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'listings' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
              onClick={() => setActiveTab('listings')}
            >
              All Listings
            </button>
            <button 
              className={`py-4 text-sm font-medium border-b-2 transition-colors flex items-center ${activeTab === 'verify' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
              onClick={() => setActiveTab('verify')}
            >
              Pending Verifications <Badge className="ml-2 bg-orange-500 text-white">3</Badge>
            </button>
            <button 
              className={`py-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'complaints' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
              onClick={() => setActiveTab('complaints')}
            >
               Complaints
            </button>
          </div>

          <div className="p-0">
            {activeTab === 'listings' && (
              <div className="divide-y">
                {hostels.map(h => (
                  <div key={h.id} className="p-4 flex items-center justify-between hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded bg-muted overflow-hidden shrink-0">
                        <img src={h.imageUrl} alt={h.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{h.name}</h4>
                        <div className="flex items-center text-xs text-muted-foreground gap-2 mt-1">
                          <span className="flex items-center"><MapPin className="w-3 h-3 mr-1" />{h.area}</span>
                          <span>•</span>
                          <span className="flex items-center"><Building2 className="w-3 h-3 mr-1" />{h.type}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                       <div className="hidden md:block font-mono font-medium">₹{h.rent}/mo</div>
                       <Badge variant="outline" className="text-green-600 bg-green-50">Active</Badge>
                       <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'verify' && (
              <div className="p-8 text-center text-muted-foreground min-h-[300px] flex flex-col justify-center items-center">
                 <ShieldAlert className="w-12 h-12 mb-4 text-orange-500/50" />
                 <h3 className="text-lg font-medium text-foreground mb-2">3 pending registrations</h3>
                 <p className="max-w-md mx-auto mb-6">These properties require physical document verification and photo checks before they can be listed publicly on StayNest.</p>
                 <Button variant="outline">Start Verification Flow</Button>
              </div>
            )}
            
            {activeTab === 'complaints' && (
              <div className="p-8 text-center text-muted-foreground min-h-[300px] flex flex-col justify-center items-center">
                 <p>No active complaints to resolve.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
