import { useState } from "react";
import { Calculator, Users, Lightbulb, IndianRupee, ShieldCheck } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { colleges } from "../data/mockData";

export default function Tools() {
  const [rent, setRent] = useState("");
  const [food, setFood] = useState("");
  const [travel, setTravel] = useState("");
  const [utilities, setUtilities] = useState("");
  
  const totalExpense = (Number(rent) || 0) + (Number(food) || 0) + (Number(travel) || 0) + (Number(utilities) || 0);

  return (
    <div className="flex-1 container mx-auto px-4 py-12 max-w-5xl">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4 font-sans text-foreground">Student Tools</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Smart utilities designed specifically for engineering students in Pune to manage expenses, find roommates, and stay safe.
        </p>
      </div>

      <Tabs defaultValue="expense" className="w-full">
        <TabsList className="grid grid-cols-1 md:grid-cols-3 h-auto gap-2 md:gap-0 p-1 bg-muted/50 rounded-xl mb-8">
          <TabsTrigger value="expense" className="py-3 data-[state=active]:bg-background rounded-lg text-base"><IndianRupee className="w-4 h-4 mr-2" /> Expense Calculator</TabsTrigger>
          <TabsTrigger value="roommate" className="py-3 data-[state=active]:bg-background rounded-lg text-base"><Users className="w-4 h-4 mr-2" /> Roommate Finder</TabsTrigger>
          <TabsTrigger value="smart" className="py-3 data-[state=active]:bg-background rounded-lg text-base"><Lightbulb className="w-4 h-4 mr-2" /> Smart Recommend</TabsTrigger>
        </TabsList>
        
        <TabsContent value="expense" className="animate-in fade-in-50 duration-500">
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <Card className="shadow-lg border-muted">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center"><Calculator className="mr-2" /> Monthly Estimate</CardTitle>
                <CardDescription>Input your budget constraints to calculate monthly expenses.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Rent / Hostel Fee (monthly)</label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="number" placeholder="5000" className="pl-9" value={rent} onChange={(e) => setRent(e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Food & Mess</label>
                  <div className="relative">
                     <IndianRupee className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="number" placeholder="3000" className="pl-9" value={food} onChange={(e) => setFood(e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Travel (Bus/Auto)</label>
                  <div className="relative">
                     <IndianRupee className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="number" placeholder="1000" className="pl-9" value={travel} onChange={(e) => setTravel(e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Utilities & Misc (WiFi, Laundry)</label>
                  <div className="relative">
                     <IndianRupee className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="number" placeholder="800" className="pl-9" value={utilities} onChange={(e) => setUtilities(e.target.value)} />
                  </div>
                </div>
                <Button className="w-full" onClick={() => {}}>Calculate Plan</Button>
              </CardContent>
            </Card>

            <Card className="bg-primary text-primary-foreground border-transparent shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl">Total Budget needed</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="flex items-baseline mb-4">
                  <span className="text-7xl font-black font-mono tracking-tighter">₹{totalExpense}</span>
                </div>
                <p className="text-primary-foreground/80 font-medium">Per Month</p>
                
                <div className="w-full mt-12 bg-white/10 rounded-xl p-4">
                   <h4 className="font-bold mb-3">Tips for Pune Students:</h4>
                   <ul className="space-y-2 text-sm text-primary-foreground/90 list-disc list-inside">
                     <li>PMT student bus passes save ~₹500/mo.</li>
                     <li>Combined PG rentals (with food) often cost less than separate hostel + mess.</li>
                     <li>Look for spaces in Kothrud/Dhankawadi for budget food options.</li>
                   </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="roommate" className="animate-in fade-in-50 duration-500">
           <Card className="shadow-lg border-muted">
              <CardHeader className="text-center pb-8 border-b mb-8">
                <CardTitle className="text-3xl">Find Your Ideal Roommate</CardTitle>
                <CardDescription className="text-lg">Match with students based on college, branch, and habits.</CardDescription>
              </CardHeader>
              <CardContent className="max-w-xl mx-auto space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your College</label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select your college" /></SelectTrigger>
                    <SelectContent>
                      {colleges.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Branch / Major</label>
                    <Input placeholder="e.g. Computer Science" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Year</label>
                    <Select>
                      <SelectTrigger><SelectValue placeholder="Select Year" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">First Year (FE)</SelectItem>
                        <SelectItem value="2">Second Year (SE)</SelectItem>
                        <SelectItem value="3">Third Year (TE)</SelectItem>
                        <SelectItem value="4">Final Year (BE)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Sleep Schedule</label>
                  <Select>
                    <SelectTrigger><SelectValue placeholder="Select preference" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="early">Early Bird (Sleeps before 11 PM)</SelectItem>
                      <SelectItem value="late">Night Owl (Studies late night)</SelectItem>
                      <SelectItem value="flex">Flexible</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button size="lg" className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white border-0">Find Match</Button>
              </CardContent>
            </Card>
        </TabsContent>

        <TabsContent value="smart" className="animate-in fade-in-50 duration-500">
           <div className="bg-gradient-to-br from-indigo-900 via-zinc-950 to-orange-950 rounded-2xl p-8 md:p-12 text-white border border-white/10 shadow-2xl relative overflow-hidden">
             
             {/* Decorative background circle */}
             <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-orange-500/20 blur-[100px] rounded-full pointer-events-none" />
             <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-indigo-500/20 blur-[100px] rounded-full pointer-events-none" />
             
             <div className="max-w-2xl mx-auto text-center space-y-6 relative z-10">
               <Lightbulb className="w-16 h-16 text-orange-400 mx-auto drop-shadow-lg" />
               <h2 className="text-3xl md:text-4xl font-black tracking-tight" style={{fontFamily: "'Inter', sans-serif"}}>AI Powered Suggestion</h2>
               <p className="text-white/70 text-lg">Tell us your budget, college, and priorities (e.g. "I want AC and good food under ₹7k near COEP") and our engine will find the perfect nest for you.</p>
               
               <div className="bg-white/10 p-2 rounded-2xl flex items-center mt-8 backdrop-blur-sm border border-white/10 focus-within:ring-2 ring-primary transition-all">
                 <Input 
                   className="bg-transparent border-0 text-white placeholder:text-white/40 focus-visible:ring-0 text-lg py-6"
                   placeholder="E.g. Safe girls PG near MIT under 8k with AC..." 
                 />
                 <Button className="rounded-xl px-8 h-12 bg-white text-black hover:bg-white/90">Suggest</Button>
               </div>
               
               <div className="pt-8 flex justify-center gap-6 text-sm text-white/50 font-medium">
                 <span className="flex items-center"><ShieldCheck className="w-4 h-4 mr-1 text-blue-400"/> Safety evaluated</span>
                 <span className="flex items-center"><IndianRupee className="w-4 h-4 mr-1 text-green-400"/> Budget matched</span>
               </div>
             </div>
           </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
