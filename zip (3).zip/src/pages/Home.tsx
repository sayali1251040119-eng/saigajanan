import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Search, MapPin, ShieldCheck, IndianRupee, Users, Building2, CheckCircle2, ChevronRight, Play } from "lucide-react";
import { Badge } from "../components/ui/badge";
import { colleges, hostels } from "../data/mockData";
import { motion } from "motion/react";

export default function Home() {
  const featuredHostels = hostels.filter(h => h.rating >= 4.5).slice(0, 3);

  return (
    <div className="flex-1 w-full flex flex-col font-sans">
      {/* Editorial / Impact Hero Section */}
      <section className="relative w-full min-h-[90vh] overflow-hidden bg-[#0A0A0A] text-white flex flex-col justify-center">
        {/* Dynamic Background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
          <motion.div 
            animate={{ 
              backgroundPosition: ["0% 0%", "100% 100%"],
            }}
            transition={{ repeat: Infinity, duration: 20, ease: "linear", repeatType: "reverse" }}
            className="absolute -top-40 -right-40 w-[600px] h-[600px] bg-orange-600/30 blur-[120px] rounded-full mix-blend-screen pointer-events-none"
          />
          <motion.div 
            animate={{ 
              backgroundPosition: ["100% 100%", "0% 0%"],
            }}
            transition={{ repeat: Infinity, duration: 25, ease: "linear", repeatType: "reverse" }}
            className="absolute bottom-0 left-20 w-[500px] h-[500px] bg-indigo-600/20 blur-[100px] rounded-full mix-blend-screen pointer-events-none"
          />
        </div>
        
        <div className="container relative z-10 px-4 md:px-6 mx-auto pt-20">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            
            {/* Value Proposition Left */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="flex flex-col space-y-6"
            >
              <div className="inline-flex items-center rounded-full border border-orange-500/30 bg-orange-500/10 px-3 py-1 text-sm font-medium text-orange-400 w-fit backdrop-blur-md">
                <span className="flex h-2 w-2 rounded-full bg-orange-500 mr-2 animate-pulse"></span>
                The #1 Student Housing Platform in Pune
              </div>
              
              <h1 className="text-5xl md:text-6xl lg:text-[80px] font-black leading-[0.9] tracking-tighter text-white">
                YOUR CAMPUS.<br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-zinc-500">YOUR ROOM.</span><br/>
                <span className="text-orange-500">YOUR NEST.</span>
              </h1>
              
              <p className="text-zinc-400 text-lg md:text-xl max-w-lg leading-relaxed font-normal">
                Skip the broker fees. Find verified hostels, connect with roommates, and calculate your budget near COEP, PICT, and top engineering colleges.
              </p>
              
              <div className="w-full max-w-md bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-2 mt-4 flex items-center shadow-2xl transition-all focus-within:bg-white/10 focus-within:border-orange-500/50">
                <div className="flex-1 flex items-center px-4">
                  <MapPin className="text-orange-500 h-5 w-5 mr-3" />
                  <input 
                    type="text" 
                    placeholder="Search college, e.g. COEP..." 
                    className="w-full bg-transparent border-none outline-none text-white placeholder:text-zinc-500 font-medium h-12"
                  />
                </div>
                <Button size="lg" className="rounded-xl bg-orange-500 hover:bg-orange-600 text-white px-6 h-12 shadow-[0_0_20px_rgba(249,115,22,0.4)] transition-all">
                  <Search className="h-4 w-4 md:mr-2" /> <span className="hidden md:inline">Find Stays</span>
                </Button>
              </div>
              
              <div className="flex items-center gap-6 pt-4 text-sm text-zinc-400 font-medium">
                 <div className="flex -space-x-3">
                   <div className="w-8 h-8 rounded-full border-2 border-[#0a0a0a] bg-zinc-800"><img src="https://i.pravatar.cc/100?img=1" className="w-full h-full rounded-full object-cover"/></div>
                   <div className="w-8 h-8 rounded-full border-2 border-[#0a0a0a] bg-zinc-800"><img src="https://i.pravatar.cc/100?img=5" className="w-full h-full rounded-full object-cover"/></div>
                   <div className="w-8 h-8 rounded-full border-2 border-[#0a0a0a] bg-zinc-800"><img src="https://i.pravatar.cc/100?img=8" className="w-full h-full rounded-full object-cover"/></div>
                   <div className="w-8 h-8 rounded-full border-2 border-[#0a0a0a] bg-zinc-800 flex items-center justify-center text-[10px] text-white bg-orange-600">+2k</div>
                 </div>
                 <p>Students trusted us this year.</p>
              </div>
            </motion.div>

            {/* Visual Graphic Right */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
              className="relative hidden lg:block h-[600px]"
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[80%] h-[80%] bg-zinc-900 rounded-[40px] border border-white/10 overflow-hidden shadow-2xl">
                <img src="https://picsum.photos/seed/hosteldorm/800/1000" className="w-full h-full object-cover opacity-60 mix-blend-luminosity hover:mix-blend-normal transition-all duration-700" alt="Student Dorm" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-tr from-black/80 via-transparent to-transparent" />
              </div>
              
              {/* Floating Element 1 - Safety Card */}
              <motion.div 
                 animate={{ y: [0, -10, 0] }}
                 transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
                 className="absolute left-0 top-[20%] bg-white/10 backdrop-blur-xl border border-white/20 p-4 rounded-2xl shadow-2xl flex items-center gap-4 w-64"
              >
                <div className="w-12 h-12 rounded-full bg-green-500/20 text-green-400 flex flex-col items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white font-bold text-lg leading-tight">98/100 Safety</p>
                  <p className="text-zinc-400 text-xs mt-0.5">Verified Wardens & CCTV</p>
                </div>
              </motion.div>
              
              {/* Floating Element 2 - Video Card */}
              <motion.div 
                 animate={{ y: [0, 15, 0] }}
                 transition={{ repeat: Infinity, duration: 6, ease: "easeInOut", delay: 1 }}
                 className="absolute -left-12 bottom-[25%] bg-white p-2 rounded-2xl shadow-2xl flex flex-col gap-2 w-56"
              >
                <div className="w-full h-32 rounded-xl bg-muted overflow-hidden relative group cursor-pointer">
                  <img src="https://picsum.photos/seed/b1/400/300" className="w-full h-full object-cover" alt="tour" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-4 h-4 text-orange-600 ml-1" />
                    </div>
                  </div>
                </div>
                <div className="px-2 pb-1">
                  <p className="text-zinc-900 font-bold text-sm">COEP Boys Hostel</p>
                  <p className="text-zinc-500 text-xs">Virtual 360° Tour</p>
                </div>
              </motion.div>
            </motion.div>
            
          </div>
        </div>
      </section>

      {/* Editorial Top Colleges Section */}
      <section className="py-20 md:py-32 bg-white">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
            <div className="max-w-2xl">
              <div className="text-orange-600 font-bold uppercase tracking-widest text-sm mb-3">Location Focus</div>
              <h2 className="text-4xl md:text-5xl font-black text-zinc-900 tracking-tight leading-[1.1]">
                Top Engineering Hubs <br className="hidden md:block"/> Across Pune.
              </h2>
            </div>
            <p className="text-zinc-500 md:text-right max-w-xs text-lg pb-2">We map the safest and most budget-friendly hostels exactly where you study.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {colleges.slice(0, 4).map((college, idx) => (
              <motion.div 
                key={college.id}
                whileHover={{ y: -8 }}
                className="group relative h-80 rounded-3xl overflow-hidden cursor-pointer"
              >
                <img 
                  src={`https://picsum.photos/seed/${college.area}/600/800`} 
                  alt={college.name} 
                  className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-700 blur-[2px] group-hover:blur-0" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
                
                <div className="absolute inset-0 p-6 flex flex-col justify-between">
                  <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white flex items-center justify-center">
                    <span className="font-bold text-lg font-mono">0{idx + 1}</span>
                  </div>
                  <div>
                    <Badge variant="outline" className="text-white border-white/30 bg-white/10 backdrop-blur-md mb-3 px-3 py-1 font-medium tracking-wide">
                      {college.area}
                    </Badge>
                    <h3 className="font-bold text-2xl text-white leading-tight mb-2 group-hover:text-orange-400 transition-colors">{college.name}</h3>
                    <div className="flex items-center text-white/70 text-sm font-medium opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                      Explore Hostels <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Hostels */}
      <section className="py-16 md:py-24 container px-4 md:px-6 mx-auto">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight mb-2">Featured Hostels</h2>
            <p className="text-muted-foreground">Top rated stays by students.</p>
          </div>
          <Button variant="outline" asChild>
            <Link to="/hostels">View all</Link>
          </Button>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {featuredHostels.map((hostel) => (
            <Link to={`/hostels/${hostel.id}`} key={hostel.id}>
              <Card className="overflow-hidden hover:shadow-lg transition-all group">
                <div className="w-full h-48 overflow-hidden relative">
                  <img src={hostel.imageUrl} alt={hostel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                  <div className="absolute top-3 left-3 bg-white/90 dark:bg-black/80 px-2 py-1 rounded text-xs font-semibold backdrop-blur-sm">
                    {hostel.type}
                  </div>
                </div>
                <CardContent className="p-5">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-bold text-lg mb-1 group-hover:text-orange-500 transition-colors">{hostel.name}</h3>
                      <p className="text-sm text-muted-foreground flex items-center">
                        <MapPin className="h-3 w-3 mr-1" /> {hostel.area}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400 px-2 py-1 rounded text-sm font-bold">
                      ⭐ {hostel.rating}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-6">
                    <div className="p-2 bg-muted rounded-lg flex-1">
                      <p className="text-xs text-muted-foreground mb-1">Starting Rent</p>
                      <p className="font-bold font-mono">₹{hostel.rent}<span className="text-sm font-sans font-normal text-muted-foreground">/mo</span></p>
                    </div>
                    <div className="p-2 bg-orange-50 dark:bg-orange-950/30 rounded-lg flex-1">
                      <p className="text-xs text-orange-600/80 mb-1">Safety Score</p>
                      <p className="font-bold text-orange-600 flex items-center"><ShieldCheck className="w-4 h-4 mr-1" /> {hostel.safetyScore}/100</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Unique Features Bento Grid */}
      <section className="py-20 md:py-32 bg-zinc-50 relative">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-orange-50 dark:bg-orange-950/10 rounded-l-[100px] pointer-events-none" />
        
        <div className="container px-4 md:px-6 mx-auto relative z-10">
          <div className="flex flex-col mb-16 max-w-2xl">
            <div className="text-orange-600 font-bold uppercase tracking-widest text-sm mb-3">Student Toolkit</div>
            <h2 className="text-4xl md:text-5xl font-black text-zinc-900 tracking-tight mb-4">
              Everything you need to <br /> make the right choice.
            </h2>
            <p className="text-zinc-500 text-lg">Powerful tools built exclusively for the Pune student ecosystem.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            
            {/* Bento 1 - Safety Score */}
            <div className="md:col-span-2 bg-zinc-900 text-white p-8 md:p-12 rounded-3xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/pattern1/800/600')] opacity-10 mix-blend-overlay group-hover:scale-105 transition-transform duration-700 pointer-events-none"></div>
              <div className="absolute right-0 bottom-0 w-[60%] h-full bg-gradient-to-l from-orange-500/20 to-transparent pointer-events-none" />
              
              <div className="relative z-10 w-full md:w-3/5">
                <div className="w-16 h-16 rounded-2xl bg-orange-500 flex items-center justify-center mb-8 shadow-lg shadow-orange-500/20">
                  <ShieldCheck className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl font-black mb-4">Safety Score Meter</h3>
                <p className="text-zinc-400 mb-8 text-lg leading-relaxed">
                  We don't just list rentals. Every hostel is ranked by CCTV availability, warden presence, curfews, and proximity to major hospitals or police stations.
                </p>
                <Button className="rounded-full bg-white text-black hover:bg-zinc-200" asChild>
                  <Link to="/hostels">Explore Safest Hostels</Link>
                </Button>
              </div>
              
              {/* Graphic Element */}
              <div className="absolute top-1/2 -translate-y-1/2 -right-20 md:-right-4 w-[280px] h-[280px] rounded-full border-[20px] border-orange-500/10 flex items-center justify-center">
                 <div className="text-7xl font-black font-mono text-orange-400/50">98</div>
              </div>
            </div>
            
            {/* Bento 2 - Expense */}
            <div className="bg-orange-500 text-white p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-[100px] pointer-events-none transition-all group-hover:scale-110" />
              <div>
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mb-6">
                  <IndianRupee className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-black mb-3">Expense Calculator</h3>
                <p className="text-white/80 leading-relaxed mb-6">
                  Plan your monthly budget. Get a clear estimate of rent, food, travel, and utility expenses.
                </p>
              </div>
              <Button variant="secondary" className="w-fit rounded-full bg-white text-orange-600 hover:bg-zinc-100 mt-auto" asChild>
                <Link to="/tools">Calculate</Link>
              </Button>
            </div>

            {/* Bento 3 - Roommate Find */}
            <div className="bg-white border border-zinc-200 p-8 rounded-3xl relative overflow-hidden flex flex-col justify-between shadow-xl shadow-zinc-200/50 group">
              <div>
                <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mb-6 text-indigo-600">
                  <Users className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-black text-zinc-900 mb-3">Roommate Finder</h3>
                <p className="text-zinc-500 leading-relaxed mb-6">
                  Match with students from your college or branch based on lifestyle preferences and study habits.
                </p>
              </div>
              <Button variant="outline" className="w-fit rounded-full border-indigo-200 text-indigo-600 hover:bg-indigo-50 mt-auto group-hover:border-indigo-600" asChild>
                <Link to="/tools">Find a Match</Link>
              </Button>
            </div>
            
            {/* Bento 4 - Smart Engine */}
            <div className="md:col-span-2 bg-indigo-950 text-white p-8 md:p-10 rounded-3xl relative overflow-hidden flex items-center justify-between">
               <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/grid/800/300')] opacity-20 mix-blend-luminosity pointer-events-none"></div>
               
               <div className="relative z-10 w-full flex flex-col md:flex-row items-center justify-between gap-8">
                 <div>
                   <h3 className="text-2xl md:text-3xl font-black mb-2 flex items-center gap-3">
                     <span className="text-indigo-400">✧</span> AI Recommendation Engine
                   </h3>
                   <p className="text-indigo-200">Tell us what you want, we find the perfect stay.</p>
                 </div>
                 <div className="bg-white/10 backdrop-blur-md border border-white/20 p-2 rounded-full flex items-center w-full md:w-auto max-w-sm shrink-0">
                    <span className="text-zinc-400 text-sm px-4 whitespace-nowrap overflow-hidden text-ellipsis">"AC room under 7k near VIT..."</span>
                    <Button className="rounded-full bg-indigo-500 hover:bg-indigo-600 shadow-lg ml-auto shrink-0">Search</Button>
                 </div>
               </div>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 md:py-16 bg-muted/30">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center font-bold text-lg mb-4 text-foreground">
            <Building2 className="mr-2" /> StayNest
          </p>
          <p>© 2026 StayNest. For Pune Engineering Students.</p>
        </div>
      </footer>
    </div>
  );
}
