export interface College {
  id: string;
  name: string;
  area: string;
  type: string;
}

export interface Amenity {
  id: string;
  label: string;
  icon: string;
}

export interface Hostel {
  id: string;
  name: string;
  type: 'Boys' | 'Girls' | 'Unisex';
  area: string;
  rent: number;
  rating: number;
  distance: number; // in km from random college
  amenities: string[];
  safetyScore: number;
  availableRooms: number;
  imageUrl: string;
  description: string;
  curfew: string;
}

export interface Review {
  id: string;
  hostelId: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export const colleges: College[] = [
  { id: '1', name: 'COEP Technological University', area: 'Shivajinagar', type: 'Government' },
  { id: '2', name: 'MIT World Peace University', area: 'Kothrud', type: 'Private' },
  { id: '3', name: 'Vishwakarma Institute of Technology (VIT)', area: 'Bibwewadi', type: 'Private' },
  { id: '4', name: 'Pune Institute of Computer Technology (PICT)', area: 'Dhankawadi', type: 'Private' },
  { id: '5', name: 'Bharati Vidyapeeth College of Engineering', area: 'Katraj', type: 'Private' },
  { id: '6', name: 'DY Patil College of Engineering', area: 'Akurdi', type: 'Private' },
  { id: '7', name: 'AISSMS College of Engineering', area: 'Shivajinagar', type: 'Private' },
  { id: '8', name: 'PCCOE', area: 'Nigdi', type: 'Private' },
];

export const hostels: Hostel[] = [
  // Boys
  {
    id: 'b1', name: 'COEP Boys Hostel', type: 'Boys', area: 'Shivajinagar', rent: 6500, rating: 4.5,
    distance: 0.5, amenities: ['WiFi', 'Mess', 'Laundry', 'Security'], safetyScore: 92,
    availableRooms: 12, imageUrl: 'https://picsum.photos/seed/b1/600/400',
    description: 'Official boys hostel for COEP students with modern amenities and strict security.',
    curfew: '10:00 PM'
  },
  {
    id: 'b2', name: 'Om Boys Residency', type: 'Boys', area: 'Bibwewadi', rent: 5800, rating: 4.2,
    distance: 1.2, amenities: ['AC', 'Parking', 'WiFi'], safetyScore: 85,
    availableRooms: 5, imageUrl: 'https://picsum.photos/seed/b2/600/400',
    description: 'Comfortable residency near VIT with spacious rooms and AC.',
    curfew: '10:30 PM'
  },
  {
    id: 'b3', name: 'Metro Boys Rooms', type: 'Boys', area: 'Shivajinagar', rent: 7000, rating: 4.1,
    distance: 2.0, amenities: ['Furnished', 'CCTV', 'WiFi'], safetyScore: 88,
    availableRooms: 8, imageUrl: 'https://picsum.photos/seed/b3/600/400',
    description: 'Fully furnished rooms with high-speed internet and CCTV surveillance.',
    curfew: '11:00 PM'
  },
  {
    id: 'b4', name: 'Royal Stay Boys PG', type: 'Boys', area: 'Akurdi', rent: 6200, rating: 4.4,
    distance: 0.8, amenities: ['Food Included', 'WiFi', 'Laundry'], safetyScore: 90,
    availableRooms: 3, imageUrl: 'https://picsum.photos/seed/b4/600/400',
    description: 'Premium PG providing 3 meals a day and laundry service.',
    curfew: '10:00 PM'
  },
  
  // Girls
  {
    id: 'g1', name: 'COEP Girls Hostel', type: 'Girls', area: 'Shivajinagar', rent: 7000, rating: 4.8,
    distance: 0.5, amenities: ['Security', 'Mess', 'Study Hall'], safetyScore: 98,
    availableRooms: 0, imageUrl: 'https://picsum.photos/seed/g1/600/400',
    description: 'Highly secure official girls hostel with a dedicated study hall.',
    curfew: '9:00 PM'
  },
  {
    id: 'g2', name: 'Sai Girls PG', type: 'Girls', area: 'Bibwewadi', rent: 6500, rating: 4.3,
    distance: 1.5, amenities: ['Attached Bathroom', 'WiFi', 'Security'], safetyScore: 95,
    availableRooms: 10, imageUrl: 'https://picsum.photos/seed/g2/600/400',
    description: 'Safe and clean PG with attached bathrooms and continuous water supply.',
    curfew: '9:30 PM'
  },
  {
    id: 'g3', name: 'Sunrise Girls PG', type: 'Girls', area: 'Katraj', rent: 5500, rating: 4.0,
    distance: 2.2, amenities: ['Laundry', 'CCTV', 'Meals'], safetyScore: 89,
    availableRooms: 15, imageUrl: 'https://picsum.photos/seed/g3/600/400',
    description: 'Budget friendly PG near Bharati Vidyapeeth with essential facilities.',
    curfew: '9:00 PM'
  },
  {
    id: 'g4', name: 'Green Nest Ladies Hostel', type: 'Girls', area: 'Kothrud', rent: 7500, rating: 4.6,
    distance: 1.0, amenities: ['Fully Furnished', 'AC', 'Security', 'Gym'], safetyScore: 96,
    availableRooms: 2, imageUrl: 'https://picsum.photos/seed/g4/600/400',
    description: 'Luxury ladies hostel with a gym and fully furnished AC rooms.',
    curfew: '10:00 PM'
  },

  // Unisex
  {
    id: 'u1', name: 'Student Hub Rooms', type: 'Unisex', area: 'Dhankawadi', rent: 6000, rating: 4.1,
    distance: 1.8, amenities: ['WiFi', 'Parking', 'Kitchen'], safetyScore: 82,
    availableRooms: 6, imageUrl: 'https://picsum.photos/seed/u1/600/400',
    description: 'Independent student rooms with shared kitchen facilities.',
    curfew: 'No Curfew'
  },
  {
    id: 'u2', name: 'Happy Homes PG', type: 'Unisex', area: 'Nigdi', rent: 5200, rating: 4.2,
    distance: 3.5, amenities: ['Furnished', 'WiFi', 'Meals'], safetyScore: 85,
    availableRooms: 14, imageUrl: 'https://picsum.photos/seed/u2/600/400',
    description: 'Homely environment with nutritious meals included.',
    curfew: '11:00 PM'
  },
  {
    id: 'u3', name: 'Smart Living Rooms', type: 'Unisex', area: 'Kothrud', rent: 8000, rating: 4.7,
    distance: 1.2, amenities: ['AC', 'WiFi', 'Cleaning', 'Security'], safetyScore: 91,
    availableRooms: 4, imageUrl: 'https://picsum.photos/seed/u3/600/400',
    description: 'Premium smart rooms with daily cleaning and smart locks.',
    curfew: 'No Curfew'
  },
  {
    id: 'u4', name: 'Urban Nest Rentals', type: 'Unisex', area: 'Wakad', rent: 7200, rating: 4.3,
    distance: 4.0, amenities: ['Gym', 'Pool', 'Parking'], safetyScore: 88,
    availableRooms: 20, imageUrl: 'https://picsum.photos/seed/u4/600/400',
    description: 'Apartment style rentals with society amenities like gym and pool.',
    curfew: 'No Curfew'
  }
];

export const reviews: Review[] = [
  { id: 'r1', hostelId: 'b1', author: 'Rahul D.', rating: 5, comment: 'Great place, very close to college.', date: '2023-08-12' },
  { id: 'r2', hostelId: 'b1', author: 'Amit S.', rating: 4, comment: 'Food is okay, but location is unbeatable.', date: '2023-09-01' },
  { id: 'r3', hostelId: 'g1', author: 'Sneha P.', rating: 5, comment: 'Very safe and clean.', date: '2023-07-20' },
  { id: 'r4', hostelId: 'u3', author: 'Vikram M.', rating: 4, comment: 'A bit pricey but the facilities are top notch.', date: '2023-10-15' },
];
